### Stockfish.js

<a href="https://github.com/nmrugg/stockfish.js">Stockfish.js</a> is a WASM implementation by Nathan Rugg of the <a href="https://github.com/official-stockfish/Stockfish">Stockfish</a> chess engine, for [Chess.com's](https://www.chess.com/analysis) in-browser engine.

Stockfish.js is currently updated to Stockfish 18.

> [!IMPORTANT]
> See <a href="https://github.com/nmrugg/stockfish.js/releases">Releases page</a> for the compiled files to download.

This edition of Stockfish.js comes in five flavors:

 * The large multi-threaded engine:
    * This is strongest version of the engine, but it is large (>100MB) and will only run in browsers with the proper <a href=https://web.dev/articles/cross-origin-isolation-guide>CORS headers</a> applied. This engine is recommended if possible.
    * Files: `stockfish-nnue-18-[0-9a-f].js` & `stockfish-nnue-18-[0-9a-f]-part-\d.wasm`
 * The large single-threaded engine:
    * This is also large but will run in browsers without CORS headers; however it cannot use multiple threads via the UCI command `setoption name Threads`. This engine is recommended if CORS support is not possible.
    * Files: `stockfish-nnue-18-single-[0-9a-f].js` & `stockfish-nnue-18-single-[0-9a-f]-part-\d.wasm`
 * The lite mult-threaded engine:
    * This is the same as the first multi-threaded but much smaller (≈7MB) and quite a bit weaker. This engine is recommended for mobile browsers when CORS is available.
    * Files: `stockfish-nnue-18-lite-[0-9a-f].js` & `stockfish-nnue-18-lite-[0-9a-f].wasm`
 * The lite single-threaded engine:
    * Same as the first single-threaded engine but much smaller (≈7MB) and quite a bit weaker. This engine is recommended for mobile browsers that do not support CORS.
    * Files: `stockfish-nnue-18-lite-single-[0-9a-f].js` & `stockfish-nnue-18-lite-single-[0-9a-f].wasm`
 * The ASM-JS engine:
    * Compiled to JavaScript, not WASM. Compatible with every browser that runs JavaScript. Very slow and weak. Larger than the lite WASM engines (≈10MB). This engine should only be used as a last resort.
    * File: `stockfish-18-asm-[0-9a-f].js`

> [!IMPORTANT]
> Due to the difficulty in handling and caching large files, the larger WASM files are split into parts. All parts are required to be in the same location and will be automatically assembled by the engine.

> [!Note]
> Also, the file names may have a hash appended to them.

The WASM Stockfish engine will run on all modern browsers (e.g., Chrome/Edge/Firefox/Opera/Safari) on supported system (Windows 10+/macOS 11+/iOS 16+/Linux/Android), as well as supported versions of Node.js. For slightly older browsers, see the <a href=../../tree/Stockfish16>Stockfish.js 16 branch</a>. The ASM-JS engine will run in essentially any browser/runtime that supports JavaScript. For an engine that supports chess variants (like 3-check and Crazyhouse), see the <a href=../../tree/Stockfish11>Stockfish.js 11 branch</a>.

### API

In the browser, it is recommended to use the engine via Web Workers. See `examples/loadEngine.js` for a sample implementation.

Stockfish.js can be found in the npm repository and installed like this: `npm install stockfish`.

If you want to use it from the command line, you may want to simply install it globally: `npm install -g stockfish`. Then you can simply run `stockfishjs`.

In Node.js, you can either run it directly from the command line (i.e., `node src/stockfish.js`) or require() it as a module (i.e., `var stockfish = require("stockfish");`).

### Compiling

You need to have <a href="https://emscripten.org/docs/getting_started/downloads.html">emscripten `3.1.7`</a> installed and in your path. Then you can compile Stockfish.js with the build script: `./build.js`. See `./build.js --help` for details. To build all flavors, run `./build.js --all`.

### Examples

There are examples in the examples folder. You will need to run the examples/server.js server to view the client-side examples. Then you can test out a simple interface at http://localhost:9091/ or a more complete demo at http://localhost:9091/demo.html.

There are also examples of how to use Stockfish.js via Node.js.

### Thanks

- <a href="https://github.com/official-stockfish/Stockfish">The Stockfish team</a>
- <a href="https://github.com/exoticorn/stockfish-js">exoticorn</a>
- <a href="https://github.com/ddugovic/Stockfish">ddugovic</a>
- <a href="https://github.com/niklasf/">niklasf</a> <a href="https://github.com/niklasf/stockfish.js">stockfish.js</a> & <a href="https://github.com/niklasf/stockfish.wasm">stockfish.wasm</a>
- <a href="https://github.com/hi-ogawa/Stockfish">hi-ogawa</a>
- <a href="https://github.com/linrock">linrock</a>
- <a href="https://www.chess.com/">Chess.com</a> for sponsering development of Stockfish.js

See <a href="https://raw.githubusercontent.com/nmrugg/stockfish.js/master/AUTHORS">AUTHORS</a> for more credits.

### License

(c) 2026, Chess.com, LLC
GPLv3 (see <a href="https://raw.githubusercontent.com/nmrugg/stockfish.js/master/Copying.txt">Copying.txt</a>)
